package com.bookiply.interview.assignment.response;

public class FirehosesLengthResponse {

    private Double totalFirehosesLength;
    private HydrantResponse[] hydrants;

    public FirehosesLengthResponse(Double totalFirehosesLength, HydrantResponse[] hydrants) {
        this.totalFirehosesLength = totalFirehosesLength;
        this.hydrants = hydrants;
    }

    public FirehosesLengthResponse() {
    }

    public Double getTotalFirehosesLength() {
        return totalFirehosesLength;
    }

    public void setTotalFirehosesLength(Double totalFirehosesLength) {
        this.totalFirehosesLength = totalFirehosesLength;
    }

    public HydrantResponse[] getHydrants() {
        return hydrants;
    }

    public void setHydrants(HydrantResponse[] hydrants) {
        this.hydrants = hydrants;
    }
}
